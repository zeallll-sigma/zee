const listsewa_ = `¥ Price Sewa Bot Autoresbot €

🔏 3 hari   = 4k
🔏 7 hari   = 10k
🔏 3 minggu = 21k
🔏 1 bulan  = 30k

Untuk Melanjutkan Sewa Silahkan Hubungi Owner`;

module.exports = {
    listsewa_
};
